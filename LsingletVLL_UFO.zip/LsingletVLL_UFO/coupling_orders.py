# This file was automatically created by FeynRules 2.3.34
# Mathematica version: 11.0.0 for Linux x86 (64-bit) (July 28, 2016)
# Date: Mon 4 Nov 2019 17:55:59


from object_library import all_orders, CouplingOrder


QCD = CouplingOrder(name = 'QCD',
                    expansion_order = 99,
                    hierarchy = 1)

NP = CouplingOrder(name = 'NP',
                   expansion_order = 99,
                   hierarchy = 1)

QED = CouplingOrder(name = 'QED',
                    expansion_order = 99,
                    hierarchy = 2)

